-- DropIndex
DROP INDEX "Like_userId_key";
