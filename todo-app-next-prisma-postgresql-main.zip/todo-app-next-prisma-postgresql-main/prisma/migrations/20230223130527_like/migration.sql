-- DropIndex
DROP INDEX "Like_postId_key";
